# Windows 桌面"密码管理器 + 登录态注入"技术可行性调研（2025–2026 现状）

> 调研方式说明：本会话 `web_search` 后端不可用（endpoint 配置错误）、`web_fetch` 受出口网络限制（部分域名被 Cloudflare/ASN 封锁），故以 `web_fetch` + Node 直连抓取官方文档/规格/GitHub 完成，所有 URL 均实际出现于抓取或检索结果中。

## Q1. Chrome/Edge cookie 保护现状

1. **第三方进程直接读写/解密 Chrome、Edge cookie 库 —— 不可行（已被封死）**。
   依据：Chrome 127 起启用 App-Bound Encryption，cookie 密钥（app_bound_encrypted_key）用 SYSTEM + 用户两级 DPAPI master key 加密、只能由 Chrome Elevation Service（iElevator COM）解密并校验调用者进程路径，普通用户态第三方进程拿不到明文密钥。
   来源：[SpecterOps: Dough No! Revisiting Cookie Theft (2025-08-27)](https://specterops.io/blog/2025/08/27/dough-no-revisiting-cookie-theft/)、[Google 安全博客: Improving security of Chrome cookies on Windows (2024-07)](https://security.googleblog.com/2024/07/improving-security-of-chrome-cookies-on.html)
   *残余攻击面均为恶意软件手法，不适合作为产品路径*：与浏览器同目录伪造调用 DecryptData COM、进程注入浏览器、SYSTEM 权限复刻解密、装恶意扩展（参见 [chrome_v20_decryption](https://github.com/runassu/chrome_v20_decryption)、[Cookie-Monster](https://github.com/KingOfTheNOPs/cookie-monster)）——等同"向浏览器注入"，触发 AV/EDR，且 Chrome 137+ 对 PostProcessData 又加了 CNG "Google Chrome key1" + AES-GCM 一层。

2. **CDP remote debugging 启动参数 —— 对默认配置文件不可行**。
   依据：Chrome 136 起 `--remote-debugging-port`/`--remote-debugging-pipe` 在默认 user data dir 下被忽略，必须搭配 `--user-data-dir` 指向非默认目录（意味着全新空 profile、无既有登录态）；Chrome 137 又移除了 `--load-extension`。
   来源：[Chrome for Developers: Remote debugging port 变更](https://developer.chrome.com/blog/remote-debugging-port)（正文经 [SpecterOps 文章](https://specterops.io/blog/2025/08/27/dough-no-revisiting-cookie-theft/)引述确认）、[SpecterOps 同上]。

3. **浏览器扩展 cookies API + native messaging —— 可行（推荐的可靠通道）**。
   依据：扩展声明 `"cookies"` 权限 + `host_permissions` 即可用 `chrome.cookies.getAll/set/remove` 读写会话（含变更事件监听），再经 native messaging 把会话交给本机应用；Edge 同为 Chromium 扩展模型，机制一致。
   来源：[Chrome cookies API 文档](https://developer.chrome.google.cn/docs/extensions/reference/api/cookies)、[Chrome Native Messaging 文档](https://developer.chrome.google.cn/docs/extensions/develop/concepts/native-messaging)。

4. **Firefox cookies.sqlite —— 受限可行（明显比 Chromium 松）**。
   依据：cookies.sqlite 可被任意本地进程复制，cookie 值由 NSS 密钥（key4.db，PBKDF2/3DES-AES）加密，未设主密码时可离线解密（firepwd 即完整实现），写入则受 Firefox 运行时锁与覆盖影响、脆弱。
   来源：[github.com/lclevy/firepwd](https://github.com/lclevy/firepwd)。

## Q2. Windows 桌面第三方 app 登录态注入

**系统级结论：Windows 没有 Android AutofillService 那样的通用表单自动填充框架 —— 不可行**。Credential Provider 只覆盖 Windows 登录/解锁 UI；Web Account Manager/WebAuthenticationBroker 只覆盖 UWP/MSA 场景；桌面 app 表单填充事实上 = UI Automation/按键模拟 + 各 app 自有凭据存储。（Credential Provider 架构页已被 Learn 下线，以 Hello for Business 文档佐证其"登录凭据"定位：[Windows Hello for Business overview](https://learn.microsoft.com/en-us/windows/security/identity-protection/hello-for-business/)）

逐条现实路径与脆弱性：

| 路径 | 结论 | 依据 + 脆弱性 | 来源 |
|---|---|---|---|
| a) 启动命令行参数 | 受限可行 | Steam 有命令行登录（SteamCMD `+login`、Steam 客户端 `-login`）；但 Steam Guard/服务端风控使跨机注入脆弱，明文口令进命令行本身是安全问题 | [Valve wiki Command line options](https://developer.valvesoftware.com/wiki/Command_line_options)（反爬未抓到正文，URL 真实）、[Steam 帮助](https://help.steampowered.com/en/faqs/view/0C48-FCBD-DAE9-2B32) |
| b1) Telegram Desktop：tdata 目录 | 受限可行 | tdata 就是会话本体，可整目录复制/转成 Telethon session；脆弱点：版本结构变更、本地 passcode、服务端 ToS/风控 | [tdata2session_converter](https://github.com/nicollasm/tdata2session_converter)、[hermes-tdata](https://github.com/Stranmor/hermes-tdata)、[Telethon_to_Tdata](https://github.com/thaithanhnhat/Telethon_to_Tdata) |
| b2) Discord：token 存储 | 受限可行 | token 在 Electron Local Storage/LevelDB，现以 DPAPI+AES-256-GCM 保护但本地仍可提取/注入；脆弱点：会话绑定、风控封号、版本改动 | [discord_token_extract](https://github.com/dannyphantomx64/discord_token_extract) |
| b3) 微信 Windows | 不可行（登录态） | 登录靠扫码/短信 + 设备绑定，无注入接口；本地数据是 SQLCipher 4，需进程内存取钥才能解密（仅只读聊天数据，不是登录态） | [wechat-4.1.12-decrypt](https://github.com/stargazer-2026/wechat-4.1.12-decrypt)、[wechat-decrypt](https://github.com/328336690/wechat-decrypt) |
| b4) Steam：loginusers.vdf 自动登录 | 受限可行 | "记住密码"态支持本机免密启动，跨机复制脆弱（Steam Guard 令牌/服务端校验） | 同 a) 来源 |
| c) Windows Credential Manager | 受限可行 | CredWrite/CredRead 是公开 API、Electron 系 app 常用（safeStorage）；但 app 是否读取完全取决于其自身实现，多数 IM/游戏不用 | [CredWriteW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-credwritew)、[ProtectedData (.NET)](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.protecteddata) |
| d) UI Automation / 按键模拟 | 可行（最通用兜底） | KeePass Auto-Type（窗口标题匹配 + 全局热键 + 按键注入）是 20 年先例；脆弱点：控件树/布局/语言变化、UAC 高完整性窗口、焦点竞争 | [KeePass Auto-Type](https://keepass.info/help/base/autotype.html)、[Windows UI Automation](https://learn.microsoft.com/en-us/windows/win32/winauto/entry-uiauto-win32) |
| e) 浏览器扩展/注入 | 浏览器内可行 | 见 Q1；对原生 app 无效 | 同 Q1 |

## Q3. 本机"临时会话签发"先例

**结论：受限可行** —— "代持真实会话 + 签发短期 scoped token"在 OAuth/API 世界已有成熟 token broker 形态；对任意网站 cookie 没有真正的 broker 产品，现实主流仍是"直接复用完整会话快照"。

- **Playwright storageState / setStorageState（最成熟先例）**：导出/回放 cookies + localStorage + IndexedDB（甚至虚拟 WebAuthn 凭据），即"向自动化客户端签发一份会话快照"。来源：[Playwright BrowserContext 文档](https://playwright.dev/docs/api/class-browsercontext)
- **mitmproxy 类本地代理**：TLS 拦截、读改流量、注入/改写 Authorization 头，可做 cookie broker 底座（代价：信任本地 CA、仅覆盖走代理的 HTTP(S)）。来源：[github.com/mitmproxy/mitmproxy](https://github.com/mitmproxy/mitmproxy)
- **会话分享/多开工具**：反检测浏览器（GoLogin/Multilogin/SessionBox）以"profile + cookie 库"管理并跨设备共享会话（GoLogin："让团队成员在另一台设备继续你的账号会话"）。来源：[gologin.com](https://gologin.com/)、[multilogin.com](https://multilogin.com/)、[sessionbox.io](https://sessionbox.io/)
- **AI 凭据托管产品（token broker 形态参照）**：Pipedream Connect（Token vault、per-user 凭据按请求注入、"revoke any account with one API call"、MCP endpoint per-user auth）、Nango（OAuth/API key/refresh 托管、凭据加密且作用域化、MCP & Tools）。来源：[pipedream.com/connect](https://www.pipedream.com/connect)、[nango.dev](https://nango.dev/)、[HashiCorp Vault dynamic secrets](https://developer.hashicorp.com/vault/docs/secrets)
- **AI 复用用户登录态**：Claude for Chrome 以扩展在用户真实浏览器内操作（直接复用登录态、重点防 prompt injection）；OpenAI Operator 用自带托管浏览器（刻意不复用本地登录）。来源：[Claude for Chrome](https://www.anthropic.com/news/claude-for-chrome)、[OpenAI Operator](https://openai.com/index/introducing-operator/)、[chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp)（可连接既有 Chrome/管理 cookie 的官方 agent 工具）
- **缺口**：没有现成"cookie broker 向 AI 客户端签发短期 scoped token"产品；短期 token 的签发/过期/撤销需自建（本地 AS / token vault 模式）。

## Q4. 本地加密库密钥保护

**结论：可行（正确用法明确）**。

- **DPAPI**：默认（不带 CRYPTPROTECT_LOCAL_MACHINE）绑定"当前用户 + 本机"，是单机单用户库的正确底座；`CRYPTPROTECT_LOCAL_MACHINE` = 本机任意用户可解，绝不可用于密钥；可加额外 entropy；基于 prompt 的流程 2027-02 弃用。来源：[CryptProtectData](https://learn.microsoft.com/en-us/windows/win32/api/dpapi/nf-dpapi-cryptprotectdata)、[ProtectedData (.NET)](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.protecteddata)
- **Windows Hello**：`UserConsentVerifier` 只做"用户在场/同意"校验（桌面 app 走 `UserConsentVerifierInterop.RequestVerificationForWindowAsync(hwnd, msg)`），本身不产生密钥 → 正确定位是"解锁 DPAPI 包裹的数据密钥"的门闩；需要密码学级绑定用 `KeyCredentialManager`（Hello 非对称密钥对、支持 TPM attestation/签名）。来源：[UserConsentVerifier](https://learn.microsoft.com/en-us/uwp/api/windows.security.credentials.ui.userconsentverifier)、[KeyCredentialManager](https://learn.microsoft.com/en-us/uwp/api/windows.security.credentials.keycredentialmanager)
- **TPM**：适合"密钥不可导出 + 远程证明/封印到启动状态"，但迁移性差（换机不可恢复）、API 重；桌面密码库常规组合 = DPAPI 为主 + Hello 门闩，TPM 为可选增强。来源：[TPM technology overview](https://learn.microsoft.com/en-us/windows/security/hardware-security/tpm/trusted-platform-module-overview)
- **Argon2id + AEAD 单文件库**：口令 → Argon2id（RFC 9106）派生主密钥 → AEAD（AES-GCM / ChaCha20-Poly1305）封装数据密钥与内容，是标准做法；KeePass KDBX4（Argon2 + AES-256/ChaCha20 + HMAC-SHA-256 块认证）与 libsodium secretstream 是标准先例；再把文件密钥用 DPAPI/Hello 包一层。来源：[RFC 9106](https://www.rfc-editor.org/rfc/rfc9106.html)、[KDBX 4 format](https://keepass.info/help/kb/kdbx_4.html)、[libsodium secretstream](https://doc.libsodium.org/secret-key_cryptography/secretstream)

## Q5. 技术栈取舍（浏览器集成 + 本地 MCP server + 托盘）

| 维度 | Tauri 2 (Rust) | .NET 8 (WPF/WinUI 3) | Electron |
|---|---|---|---|
| 安全面 | 优：不打包 WebView、capabilities/permissions ACL、IPC 白名单、CSP、Isolation Pattern | 优：无 JS 运行时；风险集中在 P/Invoke/序列化纪律 | 中：自带 Chromium + Node.js，历史漏洞面大，靠 contextIsolation 治理 |
| Windows 集成 | 中：DPAPI/Hello/Credential Manager 均可经 `windows` crate FFI，需自写 | 优：ProtectedData、UserConsentVerifier、CredWrite 一线直达 | 中：safeStorage 即 DPAPI（明确"不防同用户其他进程"）；Hello/CredMgr 需原生模块；keytar 已弃用 |
| 体积/内存 | 优：官方称最小 600KB（用系统 WebView），内存低 | 中：self-contained 单文件数十 MB，内存适中 | 差：Chromium+Node 随包，数十~上百 MB、内存高 |
| MCP SDK | 中-优：`rmcp`（官方 Rust SDK，4k star）：stdio + Streamable HTTP（Tower 服务挂 axum）、OAuth 支持、刻意不提供旧 HTTP+SSE | 中-优：`modelcontextprotocol/csharp-sdk` + `ModelContextProtocol.AspNetCore`（HTTP server）、stdio 可用、支持 Identity Assertion grant | 优：`@modelcontextprotocol/server` v2（官方 TS SDK，13.5k star）：stdio + Streamable HTTP + auth/OAuth helpers，实现 2026-07-28 spec |
| 托盘/自启/单实例 | 优：内置 tray API | 优：NotifyIcon/Windows App SDK | 优：Tray API |

**推荐**：安全敏感本地单机 + 浏览器集成 + 本地 MCP → **Tauri 2（Rust + rmcp）**（最小攻击面与体积，Windows API 走 `windows` crate）；若要最深 Windows 集成/企业部署（Hello、Credential Manager、MSI/组策略）→ **.NET 8 WPF**（WinUI 3 是微软推荐的原生 UI 框架、随 Windows App SDK 1.8 交付，但部署依赖更重）；**Electron** 仅当团队全 TS、重前端交互时选（MCP 生态最顺）。
来源：[Tauri Security](https://tauri.app/security/)、[Tauri App Size](https://tauri.app/concept/size/)、[tauri tray API](https://docs.rs/tauri/latest/tauri/tray/index.html)、[Electron 官网（embeds Chromium and Node.js）](https://www.electronjs.org/)、[Electron safeStorage](https://www.electronjs.org/docs/latest/api/safe-storage)、[WinUI 3](https://learn.microsoft.com/en-us/windows/apps/winui/)、[rust-sdk](https://github.com/modelcontextprotocol/rust-sdk)、[csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk)、[typescript-sdk](https://github.com/modelcontextprotocol/typescript-sdk)

## Q6. MCP 传输与认证现状

**结论：传输可行；认证受限可行；"工具级临时凭证"需自建但有标准骨架。**

- **传输**：stdio（本地进程；"clients SHOULD support stdio whenever possible"）+ **Streamable HTTP**（单 endpoint、POST/GET+SSE 流、`Mcp-Session-Id` 会话管理、`MCP-Protocol-Version` 头、断线续传）；旧 HTTP+SSE 已被 Streamable HTTP 取代（2025-03-26），rmcp 等新 SDK 明确不再提供。来源：[Transports spec 2025-06-18](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports)、[Transports spec 2025-11-25](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)、[rust-sdk](https://github.com/modelcontextprotocol/rust-sdk)
- **认证**：HTTP transport 上 MCP server = OAuth 2.1 resource server：401 + `WWW-Authenticate`（`resource_metadata`，RFC 9728）；客户端必须用 Resource Indicators（RFC 8707）绑定 audience、必须 PKCE、token 禁止放 query string、SHOULD 签发短时 access token + 轮换 refresh token；**stdio 实现 SHOULD NOT 走该 auth 规范**（本地进程信任模型）；server 向上游调用时 **MUST NOT 透传**收到的 token（每跳独立签发）。2025-11-25 新增：OIDC 发现、经 WWW-Authenticate 的**增量 scope 同意**（SEP-835）、非法 Origin 返回 403。来源：[Authorization spec](https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization)、[Key Changes 2025-11-25](https://modelcontextprotocol.io/specification/2025-11-25/changelog)
- **工具级临时凭证（签发/过期/撤销）**：受限可行 —— spec 无内置机制，需在本地 server 内自建小型 AS/token broker（自签或不透明 token、scope=工具名、`exp`、撤销表），用 Elicitation 做用户同意、用增量 scope consent 走标准 401/WWW-Authenticate 流程；撤销属应用层行为（OAuth Token Revocation 可选参考）。形态参照 Pipedream/Nango 的 token vault（"one API call revoke"）。

## 总结：Windows 桌面"一键带登录态启动第三方 app"的现实边界（≤5 行）

1. 浏览器内登录态可以干净复用（扩展 cookies API / storageState 快照），浏览器外没有系统级注入通道——这是一条硬边界。
2. 原生 app 只有三类现实路径：自带 CLI/自动登录（Steam 等）、复制本地会话文件（tdata/Discord token，版本脆弱且有风控封号）、UI Automation 按键填表（万能但脆）。
3. 产品正确的安全形态是"会话代持 + 快照/短期 scoped token 签发"（Playwright storageState、token vault 模式），而不是凭据直接注入。
4. 本地密钥按 DPAPI(CurrentUser) + Hello 门闩 + Argon2id/AEAD 单文件库来做；MCP 用 stdio/Streamable HTTP + 自建 token broker 发工具级临时凭证。
5. 技术栈首选 Tauri 2（rmcp）或 .NET 8 WPF；微信类扫码绑定设备的 app 登录态注入应判为不支持。
