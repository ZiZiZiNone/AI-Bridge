# 手机浏览器登录态读写通道 — 可行性调研（2025–2026 现状）

> 方法说明：web_search / web_fetch 在本环境不可用（web_search 插件端点配置错误返回 400；web_fetch 因 DNS 被解析到非公网 IP 拒绝）。已用自带 Python 自建 HTTPS 抓取 + DuckDuckGo 检索通道完成调研；原始抓取件存于 `.research/`。

## 1. iOS：Safari Web Extension 的 cookies 读写与分发

**结论：受限可行** —— iOS 18+（Safari 18）cookies.get/getAll/set 全量（含 HttpOnly）可用，iOS 15–17 只能读写非 HttpOnly cookie，且 Safari 18 有 getAll 失效的实测 bug 报告。

- `browser.cookies` 自 iOS Safari 15 提供，但 get/getAll/set 在 Safari 18 之前是 partial 实现：只操作默认 cookie store，且注明 "`HttpOnly` cookies are not retrieved / not set"；Safari 18（iOS 18，2024-09）起 get/getAll/set 记为完整实现（即含 HttpOnly）。remove/onChanged 从 iOS 15 就可用。（MDN browser-compat-data）
- 实测问题：开发者报告 Safari 18 的 `cookies.getAll` 仅在打开 Web Inspector 时工作；Safari 17 时代扩展无法携带 HttpOnly 会话 cookie 发请求（fetch 不带、cookies API 又读不到）。工程上要按"读非 HttpOnly + 降级"设计。
- 分发要求：Safari web extension 必须作为 iOS App 的 app extension 与宿主 App 一起用 Xcode 打包；需加入 Apple Developer Program（$99/年），经 App Store Connect / App Store 分发（TestFlight 内测）；iOS 15+ 可用。用户须在 设置 > Safari > 扩展 中启用并逐站授权（Always Allow / 每次询问）；MDM 可预配置启用状态与网站访问。
- 能力限制 / 宿主通信：manifest 加 `nativeMessaging` 权限 → `browser.runtime.sendNativeMessage` → 宿主 App 的 `SafariWebExtensionHandler beginRequest:`（Safari 忽略 `application.id`，只投递给自己的宿主 App）；**iOS 上只支持扩展→App 单向**（"You can't send messages from a containing iOS app to your web extension's JavaScript scripts"，App→JS 仅 macOS）；content script 不能发 native message；App Group（共享容器/UserDefaults）用于 App 与扩展共享数据。
- 备选通道：扩展 background 可自行 `fetch()` 直接向 PC/自建端点同步，不依赖宿主 App。

来源：
- https://raw.githubusercontent.com/mdn/browser-compat-data/main/webextensions/api/cookies.json
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/cookies
- https://developer.apple.com/documentation/safariservices/safari-web-extensions
- https://developer.apple.com/documentation/safariservices/messaging-between-the-app-and-javascript-in-a-safari-web-extension
- https://developer.apple.com/forums/thread/761323 （Safari 18 cookies.getAll bug）
- https://stackoverflow.com/questions/76977996/how-can-a-safari-web-extension-perform-authenticated-requests

## 2. Android：各浏览器扩展现状

**Chrome for Android：不可行。** 正式版 2025–2026 均无扩展支持；只有"桌面版 UI 的实验性 Chrome 构建"（手动拖 .crx 进 chrome://extensions）存在，未推送到普通手机（2026 年中依旧如此）；Brave 2026-10 才宣布开始做 Android 扩展。
来源：https://www.androidcentral.com/apps-software/chrome-for-android-is-getting-extensions-but-not-like-youd-expect ；https://chromeunboxed.com/a-development-version-of-chrome-for-android-now-supports-extensions/ ；https://extensionbooster.net/blog/chrome-extensions-android-2026-what-works-guide/ ；https://piunikaweb.com/2026/10/01/brave-starts-work-android-extensions/

**Firefox for Android：可行（最成熟的登录态通道）。** 2023-12-14 起开放 open extensions，AMO 标注 Android 兼容的 400+ 扩展可直接安装；cookies API 在 Firefox Android 完整支持（get/getAll/set，含 HttpOnly，无 partial 注记）；cookie 管理类扩展现成（Cookie Manager、Cookie Quick Manager 明确支持 Firefox for Android）。注意：`nativeMessaging` 对普通扩展在 Android **不可用**（仅内置扩展，Bugzilla 1739746），扩展↔本机 App 需走扩展自身网络或本地 socket。
来源：https://blog.mozilla.org/addons/2023/11/28/open-extensions-on-firefox-for-android-debut-december-14-but-you-can-get-a-sneak-peek-today/ ；https://addons.mozilla.org/en-US/android/addon/a-cookie-manager/ ；https://github.com/Rob--W/cookie-manager ；https://bugzilla.mozilla.org/show_bug.cgi?id=1739746

**Edge for Android：受限可行 → 趋近可行。** 2025-03（Edge 134）上线官方扩展商店（起始 22 个）；2025 末 beta 扩容到"几乎全部 Edge Add-ons 数千个扩展"；官方 Play 分发，但范围=微软商店目录，非任意 CRX。
来源：https://www.howtogeek.com/microsoft-edge-on-android-has-extensions-now/ ；https://techpp.com/2025/03/19/microsoft-edge-extensions-mobile/ ；https://www.androidauthority.com/microsoft-edge-chrome-extensions-upgrade-3614551/

**三星 Internet：受限可行。** 官方支持第三方扩展（上架分发），但 API 是"从 Chrome/WebExtensions 精选的子集 + 移动专用 API"，cookies API 可用性需逐项验证。
来源：https://developer.samsung.com/browser/android/extension-guide.html

**Kiwi Browser（曾可装任意 CRX）：已死。** 2025-01 停止维护、下架，扩展代码并入 Edge Canary。
来源：https://www.androidpolice.com/kiwi-browser-dead-as-a-dodo/ ；https://alternativeto.net/news/2025/1/kiwi-browser-discontinued-explore-alternatives-for-extension-support-and-security/

## 3. 第三方 App 直读浏览器 cookie 存储

**结论：不可行（双平台沙箱禁止，无官方例外）。**

- Android：每 App 独立 UID 内核沙箱；Chrome 的 Cookies 库在 `com.android.chrome` 私有目录，其它 App 无权读写。
- iOS：App 沙箱，且不存在任何读取 Safari cookie store 的 API。
- 官方"例外"边界（都是**使用**而非**提取**）：
  - Android WebView：CookieManager 管理的是本 App 私有 cookie store（与 Chrome 不互通），App 对它完全读写 → 只能承载"App 自己的"登录态。
  - Chrome Custom Tabs / TWA：共享 Chrome 的 cookie jar（复用用户 Chrome 登录态、免登录），但 App 拿不到 cookie 本身。
  - iOS SFSafariViewController：复用 Safari 会话呈现，"interactions occur solely within the view controller"，零导出 API。

来源：
- https://source.android.com/docs/security/app-sandbox
- https://chromium.googlesource.com/chromium/src/+/refs/tags/128.0.6613.5/docs/security/android-sandbox.md
- https://developer.chrome.com/docs/android/custom-tabs （"Shared cookie jar and permissions model"）
- https://developer.android.com/reference/android/webkit/CookieManager
- https://developer.apple.com/documentation/safariservices/sfsafariviewcontroller
- https://developer.apple.com/documentation/foundation/httpcookiestorage
- https://stackoverflow.com/questions/75866976/in-android-can-a-cookie-set-by-cookiemanager-setcookie-be-read-by-another-app

## 4. QR 配对 + 端到端加密直传：先例与协议选型

**结论：可行（先例充分）；局域网直连可靠，互联网直连需要 rendezvous/STUN，最难 NAT 组合需中继回落。**

成熟先例：
- **LocalSend**：纯 LAN、无服务器、每设备自签 TLS + REST/HTTPS；身份=证书 SHA-256 指纹，QR 交换/确认指纹。最贴近"扫码配对+直传"。
- **Syncthing**：设备 ID = 自签证书 DER 的 SHA-256（截断 base32），同时用于寻址与认证；配对即交换 Device ID/QR。
- **Bitwarden "Log in with device"**：QR 发起 → 设备间非对称公钥交换 → **指纹短语比对后 Confirm** → 登录请求推送到已登录设备批准。与"跨设备会话扩散"形态最像（含确认流）。
- **magic-wormhole**：SPAKE2（PAKE）从短码派生密钥 + rendezvous/mailbox + transit relay 回落；服务器只见密文。
- **Signal**：X3DH（X25519/X448）预密钥模型做异步互认证；设备链接以 QR+密钥交换+人工确认为核心；Noise 系列用于成对信道。

密钥交换选型：
1. 首选 **QR 内嵌 X25519 临时公钥 + 指纹/SAS 人工确认**（LocalSend/Syncthing 式）：简单、离线、可加 ephemeral 做前向保密。
2. 短码/人输场景用 **SPAKE2/CPace（PAKE）** 防离线爆破（wormhole 先例）。
3. 带账号体系用 **Bitwarden 式"登录请求 + 指纹短语批准"**（非对称加密传输）。

NAT 穿透现实：
- 局域网直连（mDNS/组播发现 + 直接 TLS）：可靠。
- 互联网直连：必须至少有会合点（signaling/STUN）；双方对称 NAT/CGNAT 时洞穿失败是常态，需 TURN/DERP 式中继兜底（Tailscale：P2P 优先、relay 回落）。中继转发=用互联网基础设施，但载荷 E2E 加密、中继不可读；若硬性"零服务器"，公网场景无法承诺直连。

来源：
- https://github.com/localsend/localsend
- https://github.com/mattjoyce/localsend-go/blob/main/docs/SECURITY.md
- https://docs.syncthing.net/dev/device-ids.html
- https://bitwarden.com/help/log-in-with-device/
- https://github.com/jamesrisberg/wormhole/blob/main/docs/magic-wormhole-server-protocol.md
- https://signal.org/docs/specifications/x3dh/
- https://tailscale.com/blog/how-nat-traversal-works/
- https://tailscale.com/blog/nat-traversal-improvements-pt-1

## 5. 手机端自动填充/凭据带出

**结论：可行（标准做法，成本中等）；但它搬运的是"凭据"，不是"cookie 会话"。**

- **iOS Credential Provider Extension**（`ASCredentialProviderViewController` + AutoFill Credential Provider entitlement，扩展与宿主 App 都要开）：能力=密码 +（iOS 17+）通行密钥 + 验证码，可向 QuickType 栏提供候选；用户须在 设置 > 密码（iOS 17+ 为 设置 > 通用 > 自动填充与密码）指定第三方提供方；走 App Store 审核（无特殊配额，扩展有内存/生命周期限制）。
- **Android**：AutofillService（Android 8+，`BIND_AUTOFILL_SERVICE`）→ 用户在 设置 > 密码和账号 > 自动填充服务 选择；CredentialManager（Jetpack）统一密码/通行密钥底部表；Android 14+ CredentialProviderService 进系统密码提供方（设置 > 密码 启用）。成本=中等开发量 + 常规 Play 审核 + 用户手动启用一步。
- 形态判断：填用户名密码/OTP 成熟可靠；拿不到 HttpOnly session cookie → 不能"带走登录态"，只能带走凭据后在目标端重新登录。

来源：
- https://support.apple.com/guide/security/credential-provider-extensions-sec6319ac7b9/web
- https://developer.apple.com/documentation/authenticationservices/ascredentialproviderviewcontroller
- https://developer.android.com/reference/android/service/autofill/AutofillService
- https://developers.google.com/identity/android-credential-manager
- https://developer.android.com/identity/autofill/credential-manager-autofill

## 6. 自带浏览器容器（WebView/Custom Tabs）承载登录会话

**结论：可行——App 对自家容器 cookie store 有完整读写（可导出/注入），但与系统浏览器登录态天然隔离。**

- **WKWebView**：cookie 在 `WKHTTPCookieStore`（WKWebsiteDataStore），App 私有、与 Safari 不共享；`getAllCookies`/`setCookie`/`delete` 可枚举与注入（App 是 store 属主，含 HttpOnly）→ 导出/注入可行。
- **Android WebView**：CookieManager 管理 App 私有 cookie 库，与 Chrome 不互通；`setCookie` 注入可靠；`getCookie` 历史上不返回 HttpOnly/Secure（SO 实测），但底层 Cookies SQLite 就在 App 私有目录，App 可自行读写 → 实务上可导出注入。
- **Custom Tabs**：跑在 Chrome 进程、共享 Chrome cookie jar（免登录体验），但 App 无读写 API → 只能"用"不能"拿"。
- 产品含义：要稳定携带**自己产品**的登录会话，自家 WebView 容器是最强通道；要搬运**系统浏览器既有登录态**，只能靠扩展（见 1、2）。

来源：
- https://developer.apple.com/documentation/foundation/httpcookiestorage
- https://developer.apple.com/documentation/webkit/wkhttpcookiestore/getallcookies(_:)
- https://developer.android.com/reference/android/webkit/CookieManager
- https://stackoverflow.com/questions/52653128/get-httponly-cookies-from-android-webview
- https://developer.chrome.com/docs/android/custom-tabs

## 总结：双向扩散的现实路径与死路

1. **手机浏览器登录态 → PC（可行）**：浏览器扩展读 cookie 后同步——iOS 用 Safari Web Extension（iOS 18+ 可读含 HttpOnly；经 nativeMessaging→宿主 App 或扩展自行 fetch 送出），Android 用 Firefox（cookies API 全量）/Edge（商店内扩展）/三星扩展；链路=QR 配对（X25519 公钥+指纹确认）+ E2E 直传（LAN 直连，公网 STUN/中继回落）。
2. **PC → 手机浏览器（受限可行）**：同一扩展反向 `cookies.set` 注入（iOS 18+ Safari 扩展 set 全量；Firefox Android set 全量；Edge/三星需验证）；或引导用户迁到"自家 WebView 容器"由 App 注入（WKWebView/Android WebView 均可控）。
3. **死路 A**：第三方 App 直读/直写 iOS Safari 或 Android Chrome 的 cookie 存储——双沙箱、无官方例外，放弃。
4. **死路 B**：Chrome for Android 扩展通道（2026 仍无扩展支持，实验性桌面版不算产品通道）；另注意 Firefox Android 扩展不能 nativeMessaging，App↔扩展要走网络/本地 socket。
5. **中继转发算"联网"但不算"泄密"**（E2E 密文，服务器不可读）；若硬性"零服务器"，只能保证局域网直连，公网场景无法承诺。
